# TRADEIA Haiti

Ti pwototip Kivy pou Android. Li montre yon entèfas demo sèlman.

## Fichye yo
- `main.py`: entèfas aplikasyon an.
- `buildozer.spec`: konfigirasyon Buildozer.
- `.github/workflows/build.yml`: workflow GitHub Actions pou konstwi APK debug.

## Kijan pou konstwi APK la sou GitHub
1. Kreye yon repo GitHub epi mete fichye sa yo ladan l, pandan w ap kenbe estrikti dosye yo.
2. Ale nan **Actions**.
3. Chwazi **Build TRADEIA Haiti APK** epi peze **Run workflow**.
4. Si travay la reyisi, louvri run lan epi telechaje artifact `TRADEIA-Haiti-APK`.

## Enpòtan
Aplikasyon sa a poko konekte ak MT5, pa analize mache an dirèk, pa bay siyal reyèl, epi li pa fè tranzaksyon. Se yon pwototip demonstrasyon. APK debug la pa yon aplikasyon pare pou komès reyèl.
