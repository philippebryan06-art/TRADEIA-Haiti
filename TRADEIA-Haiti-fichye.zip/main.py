from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button


class TradeAI(App):
    def build(self):
        ekran = BoxLayout(
            orientation="vertical",
            padding=20,
            spacing=12
        )

        ekran.add_widget(Label(
            text="[b]TRADEIA HAITI[/b]",
            markup=True,
            font_size=28
        ))

        ekran.add_widget(Label(
            text="Asistan analiz MT5 | Demo",
            font_size=16
        ))

        self.repons = Label(text="TradeAI pare!")
        ekran.add_widget(self.repons)

        bouton1 = Button(text="Analiz mache")
        bouton1.bind(on_press=self.analiz)
        ekran.add_widget(bouton1)

        bouton2 = Button(text="Siyal demonstrasyon")
        bouton2.bind(on_press=self.siyal)
        ekran.add_widget(bouton2)

        bouton3 = Button(text="Jesyon risk")
        bouton3.bind(on_press=self.risk)
        ekran.add_widget(bouton3)

        return ekran

    def analiz(self, bouton):
        self.repons.text = "Mache yo poko konekte."

    def siyal(self, bouton):
        self.repons.text = "Demonstrasyon sèlman."

    def risk(self, bouton):
        self.repons.text = "Toujou kontwole risk yo."


if __name__ == "__main__":
    TradeAI().run()
